# sonar_runner

#### Table of Contents

1. [Description](#description)
1. [Setup - The basics of getting started with sonar_runner](#setup)
1. [Usage - Configuration options and additional functionality](#usage)
1. [Artifactoryx](#artifactoryx)

## Description

As a SonarQube administrator I would like to ensure the latest version of SonarScanner and BuildWrapper exist on all public build nodes. This is so I can be up-to-date...

Supports
* sonar_scanner 2.8
* build-wrapper 3.8, 3.9
*
## Setup

n/a

## Usage

n/a

## Artifactoryx

* http://engci-maven-master.cisco.com/artifactory/bms-vendor-files/sonarqube/sonar-scanner
* http://engci-maven-master.cisco.com/artifactory/bms-vendor-files/sonarqube/build-wrapper
