# puppet-limits

Puppet module to set entries in /etc/security/limits.d

## limits

You should call this as a parameterised define passing in the configuration data - for example:

    limits::entry { 'user-nproc':
      domain => 'user',
      type   => 'soft',
      item   => 'nofile',
      value  => '8192',
    }

### Parameters

Each entry title is the file name that will be created - for example '/etc/security/limits.d/user-nproc.conf'

For each domain there is one or more items: one of: 'core', 'data', 'fsize',
'memlock', 'nofile', 'rss', 'stack', 'cpu', 'nproc', 'as', 'maxlogins',
'maxsyslogins', 'priority', 'locks', 'sigpending', 'msqqueue', 'nice',
'rtprio'.

For each item the following parameters are accepted:

   * *soft*: the entry will reference the item's soft limit.

   * *hard*: the entry will reference the item's hard limit.

   * *both*: the entry with reference both the item's hard and soft limit.

See the limits.conf(5) man page for more information.
