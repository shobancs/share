# Tomcat Module Configuration
==========

You should use this module to install tomcat and manage webapplications. This module assume you will be running a multi-instance
tomcat application. This class accepts no parameters.   

```
include ::tomcat
```

Included is a define that allows you to setup a multi-instance application. This define can
be called multiple times per host. There are some default values. The only required values
are app_home and artifact_url.

app_home is the name of the directory where the application will be installed.
artifact_url expects a http url where curl can download a war file.

This module will create all the required files and folders to run your application. It will
also create an init script for your application and start the service.   

```
define tomcat::app (
  $app_home,
  $artifact_url,
  $java_home     = '/bms/tools/java/jdk/current',
  $catalina_home = '/bms/tools/tomcat/current',
  $shutdown_port = $tomcat::params::shutdown_port,
  $ajp_port      = $tomcat::params::ajp_port,
  $http_port     = $tomcat::params::http_port,
  $https_port    = $tomcat::params::https_port,
  $java_xms      = $tomcat::params::java_xms,
  $java_xmx      = $tomcat::params::java_xmx,
) {
```

#### Example Profiles Manifest


```
# app1_server.pp

class profiles::app1_server {
  include ::bms_repos::bms_yum
  include ::encgi_users::pdsint

  include ::tomcat

  tomcat::app { 'app1' :
    $app_home => 'app1',
    $artifact_url = 'http://internal.example.com/apps/app1.war',
    $shutdown_port = '8005',
    $ajp_port      = '8009',
    $http_port     = '8080',
    $java_xms      = '1g',
    $java_xmx      = '2g'
  }
}
```
