Docker test to load debian packages from artifactory
----------------------------------------------------
'''
http://engci-maven-stage.cisco.com/artifactory/webapp/#/artifacts/browse/tree/General/bms-qa-debian/dists/jessie/main/binary-amd64
http://engci-maven-stage.cisco.com/artifactory/webapp/#/artifacts/browse/tree/General/bms-qa-debian
'''
